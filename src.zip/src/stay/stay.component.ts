import { Component } from '@angular/core';

@Component({
 selector: 'stay-root',
  templateUrl: './stay.component.html',
styleUrls: ['./stay.component.css']
})
export class StayComponent {
  title = 'Management';
}
import { Component } from '@angular/core';

@Component({
 selector: 'cancel-root',
  templateUrl: './cancel.component.html',
styleUrls: ['./cancel.component.css']
})
export class CancelComponent {
  title = 'Management';
}
export class User{
constructor(

public email = '',
public password=''
) { }


}
    
